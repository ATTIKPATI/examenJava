import java.time.LocalDate;
import java.util.Scanner;

public class Main {


public static void main(String[] args) {
    
String choix;
     Scanner clavier=new Scanner(System.in);
     Service service =new Service();
    do {

        System.out.println("1-Ajout Service");
        
        System.out.println("2-Lister les Services");
        System.out.println("3-Ajouter un Employé ");
        System.out.println("4-Lister les    Journaliers ");
        System.out.println("5-Lister les    Embauchés d'un Service ");
        System.out.println("6-Quitter");
        System.out.println("Faites votre choix");
        choix=clavier.nextLine();
        switch(choix){
            case "1":
            System.out.println("Entrer le libelle du service");
               String libelle =clavier.nextLine();
               Service ser=new Service(libelle);
               service.creerService(ser);
            break;

            case "2":

            service.listerService();
            break;

            case "3":
            System.out.println("Entrer le nom de l'employe");
               String nomComplet =clavier.nextLine();
               Employe emp=new Employe(nomComplet);
               service.creerEmploye(emp);

            break;

            case "4":
           service.listerJournalier();
            break;
            
            case "5":
           service.listerEmbauche();
            break;

        }
        
    } while (choix!="6");

        
}
    
}