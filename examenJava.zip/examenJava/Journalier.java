import java.time.LocalDate;
public class Journalier extends Employe {


    private int duree;
    private int forfait
    

    public Journalier(){
          }
    public Journalier(String nomComplet,
               LocalDate dateEmb,int duree,int forfait ){
            
              super(nomComplet,dateEmb);
             this.duree=duree;
             this.forfait=forfait;
            
          }
   
    @Override
    public String affiche(){
    
       return super.affiche() +" durée : "+duree+ "forfait :"+forfait; 
                    
    }
     
}