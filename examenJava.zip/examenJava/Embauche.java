import java.time.LocalDate;
public class Embauche extends Employe {


    private int salaire;
    

    public Embauche(){
          }
    public  Embauche(String nomComplet,
               LocalDate dateEmb,int salaire ){
            
              super(nomComplet,dateEmb);
             this.salaire=salaire;
            
          }
   
    @Override
    public String affiche(){
    
       return super.affiche() +" Salaire : "+salaire; 
                    
    }
     
}