public abstract class Employe realise IService{
    protected int id;
    protected  String nomComplet;
  
    protected LocalDate dateEmb;


    public Employe (String nomComplet,
              dateEmb){
      this.nomComplet=nomComplet;
     this.dateEmb=dateEmb;
     
  
       

    }
  

   public Employe (){
        
    }

   @Override
    public String affiche(){
       return "Id: "+id+" Nom et Prenom : "+nomComplet+ "la date": +dateEmb;
    }





}