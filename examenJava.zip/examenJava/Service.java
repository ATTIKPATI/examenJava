public class Service {

     private int id;
     private string libelle;
      final int TAILLE=10;
    
    
                               
      private int nbreEmploye=0;
   
     private int nbreService=0;
    private Journalier tabEmploye[];
    private Journalier tabService[];

    public Service(){
       
      
        tabEmploye=new EmployeTAILLE];
        tabService=new ServiceTAILLE];

    }

    public String affiche(){
       return "Id: "+id+" libelle"+libelle;
    }
        
    
    

   

  public void compare(int id){
       for(i=0; i<nbreService; i++){
              
                  if(tabService[i].getId()==Service.getId()){
      System.out.println("l'employe existe déjà");
}
}
   

    }
 public void compare(String libelle){
 for(i=0; i<nbreService; i++){
              
                  if(tabService[i].getLibelle()==Service.getLibelle()){
      System.out.println("l'employe existe déjà");
}
       
    }

public listerJournalier(Journalier journ){
 for(i=0; i<nbreEmploye; i++){
        if(tabEmploye[i] instanceof Journalier){
              System.out.println(tabEmploye[i].affiche());
}
}
       
    }

public listerEmbauche(Embauche emb){
 for(i=0; i<nbreEmploye; i++){
        if(tabEmploye[i] instanceof Embauche){
              System.out.println(tabEmploye[i].affiche());
}
}
       
    }



    
}